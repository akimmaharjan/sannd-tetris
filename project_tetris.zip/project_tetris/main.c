#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
/*  TO DO:
    score counter
    fully left lagda block,
    block design,fonts,
    make beautiful
    colors
    2player
    game suitable size*/

#define GAME_WIDTH 380 //size change garxau vane rakha
#define GAME_HEIGHT 660 //size change??
#define SAND_SIZE 4 
#define BLOCK_SCALE 4 
#define ROWS (GAME_HEIGHT / SAND_SIZE)
#define COLS (GAME_WIDTH / SAND_SIZE)

const int WINDOW_WIDTH = 600;
const int WINDOW_HEIGHT = 700;

typedef enum { STATE_MENU, STATE_GAME } GameState;
GameState currentState = STATE_MENU;

Uint32 sand_map[COLS][ROWS] = {0};
bool visited[COLS][ROWS] = {false};
int score = 0;

int SHAPES[4][4][4] = {
    { {1,1,0,0}, {1,1,0,0}, {0,0,0,0}, {0,0,0,0} }, // Cube
    { {1,0,0,0}, {1,0,0,0}, {1,1,0,0}, {0,0,0,0} }, // L
    { {1,0,0,0}, {1,0,0,0}, {1,0,0,0}, {1,0,0,0} }, // Long
    { {1,1,1,0}, {0,1,0,0}, {0,0,0,0}, {0,0,0,0} }  // T
};

Uint32 SHAPE_COLORS[4] = { 0xFFFFD700, 0xFF0000FF, 0xFFFF0000, 0xFF00FF00 };

typedef struct { int x, y, type; Uint32 color; bool active; } FallingPiece;
FallingPiece currentPiece;
int nextType;
Uint32 nextColor; // Track the color for the next piece preview

void spawn_piece() {
    currentPiece.type = nextType;
    currentPiece.color = nextColor; // use the color generated previously
    currentPiece.x = COLS / 2 - (2 * BLOCK_SCALE);
    currentPiece.y = 0;
    currentPiece.active = true;
    
    // make the next piece of random type and color
    nextType = rand() % 4;
    nextColor = SHAPE_COLORS[rand() % 4]; 
}

bool can_move(int newX, int newY) {
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            if (SHAPES[currentPiece.type][i][j]) {
                for (int sy = 0; sy < BLOCK_SCALE; sy++) {
                    for (int sx = 0; sx < BLOCK_SCALE; sx++) {
                        int mapX = newX + (j * BLOCK_SCALE) + sx;
                        int mapY = newY + (i * BLOCK_SCALE) + sy;
                        if (mapX < 0 || mapX >= COLS || mapY >= ROWS || sand_map[mapX][mapY] != 0) return false;
                    }
                }
            }
        }
    }
    return true;
}

bool flood_fill(int x, int y, Uint32 color, bool* touchesRight) {
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS || visited[x][y] || sand_map[x][y] != color) return false;
    visited[x][y] = true;
    if (x == COLS - 1) *touchesRight = true;
    flood_fill(x + 1, y, color, touchesRight);
    flood_fill(x - 1, y, color, touchesRight);
    flood_fill(x, y + 1, color, touchesRight);
    flood_fill(x, y - 1, color, touchesRight);
    return true;
}

void delete_path(int x, int y, Uint32 color) {
    if (x < 0 || x >= COLS || y < 0 || y >= ROWS || sand_map[x][y] != color) return;
    sand_map[x][y] = 0;
    delete_path(x + 1, y, color);
    delete_path(x - 1, y, color);
    delete_path(x, y + 1, color);
    delete_path(x, y - 1, color);
}

void check_clears() {
    for (int y = 0; y < ROWS; y++) {
        if (sand_map[0][y] != 0) {
            Uint32 targetColor = sand_map[0][y];
            for (int i = 0; i < COLS; i++) for (int j = 0; j < ROWS; j++) visited[i][j] = false;
            bool touchesRight = false;
            flood_fill(0, y, targetColor, &touchesRight);
            if (touchesRight) {
                delete_path(0, y, targetColor);
                score += 500;
            }
        }
    }
}

int main(int argc, char* argv[]) {
    srand(time(NULL)); SDL_Init(SDL_INIT_VIDEO); TTF_Init();
    SDL_Window* window = SDL_CreateWindow("Sand Tetris", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, WINDOW_WIDTH, WINDOW_HEIGHT, 0);
    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    TTF_Font* font = TTF_OpenFont("arial.ttf", 28);
    TTF_Font* titleFont = TTF_OpenFont("arial.ttf", 56);
    TTF_Font* creditFont = TTF_OpenFont("arial.ttf", 14);
    SDL_Color white = {255, 255, 255, 255};
    
    // initial random values
    nextType = rand() % 4;
    nextColor = SHAPE_COLORS[rand() % 4];
    spawn_piece();
    
    bool quit = false; SDL_Event e; int moveTimer = 0;
    SDL_Rect startButton = { WINDOW_WIDTH/2 - 75, 250, 150, 50 };
    SDL_Rect quitButton = { WINDOW_WIDTH/2 - 75, 330, 150, 50 };

    while (!quit) {
        while (SDL_PollEvent(&e)) {
            if (e.type == SDL_QUIT) quit = true;
            if (currentState == STATE_MENU) {
                if (e.type == SDL_MOUSEBUTTONDOWN) {
                    int mx = e.button.x, my = e.button.y;
                    if (mx >= startButton.x && mx <= startButton.x + startButton.w && my >= startButton.y && my <= startButton.y + startButton.h) currentState = STATE_GAME;
                    if (mx >= quitButton.x && mx <= quitButton.x + quitButton.w && my >= quitButton.y && my <= quitButton.y + quitButton.h) quit = true;
                }
            } else {
                if (e.type == SDL_KEYDOWN) {
                    if (e.key.keysym.sym == SDLK_LEFT && can_move(currentPiece.x - BLOCK_SCALE, currentPiece.y)) currentPiece.x -= BLOCK_SCALE;
                    if (e.key.keysym.sym == SDLK_RIGHT && can_move(currentPiece.x + BLOCK_SCALE, currentPiece.y)) currentPiece.x += BLOCK_SCALE;
                    if (e.key.keysym.sym == SDLK_DOWN && can_move(currentPiece.x, currentPiece.y + BLOCK_SCALE)) currentPiece.y += BLOCK_SCALE;
                }
            }
        }

        if (currentState == STATE_GAME) {
            if (moveTimer++ > 5) {
                if (can_move(currentPiece.x, currentPiece.y + 1)) currentPiece.y++;
                else {
                    for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (SHAPES[currentPiece.type][i][j])
                        for (int sy = 0; sy < BLOCK_SCALE; sy++) for (int sx = 0; sx < BLOCK_SCALE; sx++)
                            sand_map[currentPiece.x + (j * BLOCK_SCALE) + sx][currentPiece.y + (i * BLOCK_SCALE) + sy] = currentPiece.color;
                    spawn_piece();
                }
                moveTimer = 0;
            }
            bool sandMoved = false;
            for (int y = ROWS - 2; y >= 0; y--) {
                for (int x = 0; x < COLS; x++) {
                    if (sand_map[x][y] != 0) {
                        if (sand_map[x][y+1] == 0) { sand_map[x][y+1] = sand_map[x][y]; sand_map[x][y] = 0; sandMoved = true; }
                        else if (x > 0 && sand_map[x-1][y+1] == 0) { sand_map[x-1][y+1] = sand_map[x][y]; sand_map[x][y] = 0; sandMoved = true; }
                        else if (x < COLS - 1 && sand_map[x+1][y+1] == 0) { sand_map[x+1][y+1] = sand_map[x][y]; sand_map[x][y] = 0; sandMoved = true; }
                    }
                }
            }
            if (sandMoved) check_clears();
        }

        SDL_SetRenderDrawColor(renderer, 45, 40, 35, 255); SDL_RenderClear(renderer);
        if (currentState == STATE_MENU) {
            if (titleFont) {
                SDL_Surface* sT = TTF_RenderText_Solid(titleFont, "SAND TETRIS", white);
                SDL_Texture* tT = SDL_CreateTextureFromSurface(renderer, sT);
                SDL_Rect rT = { WINDOW_WIDTH/2 - sT->w/2, 80, sT->w, sT->h }; SDL_RenderCopy(renderer, tT, NULL, &rT);
                SDL_FreeSurface(sT); SDL_DestroyTexture(tT);
            }
            if (creditFont) {
                SDL_Surface* sC1 = TTF_RenderText_Solid(creditFont, "By: Akim Maharjan", white);
                SDL_Texture* tC1 = SDL_CreateTextureFromSurface(renderer, sC1);
                SDL_Rect rC1 = { 10, WINDOW_HEIGHT - 80, sC1->w, sC1->h }; 
                SDL_RenderCopy(renderer, tC1, NULL, &rC1);
                SDL_FreeSurface(sC1); SDL_DestroyTexture(tC1);
                
                SDL_Surface* sC2 = TTF_RenderText_Solid(creditFont, "      Biraj Tiwari", white);
                SDL_Texture* tC2 = SDL_CreateTextureFromSurface(renderer, sC2);
                SDL_Rect rC2 = { 10, WINDOW_HEIGHT - 60, sC2->w, sC2->h }; 
                SDL_RenderCopy(renderer, tC2, NULL, &rC2);
                SDL_FreeSurface(sC2); SDL_DestroyTexture(tC2);

                SDL_Surface* sC3 = TTF_RenderText_Solid(creditFont, "      Deepak Shrestha", white);
                SDL_Texture* tC3 = SDL_CreateTextureFromSurface(renderer, sC3);
                SDL_Rect rC3 = { 10, WINDOW_HEIGHT - 40, sC3->w, sC3->h }; 
                SDL_RenderCopy(renderer, tC3, NULL, &rC3);
                SDL_FreeSurface(sC3); SDL_DestroyTexture(tC3);

                SDL_Surface* sC4 = TTF_RenderText_Solid(creditFont, "      Sandip Chapagain", white);
                SDL_Texture* tC4 = SDL_CreateTextureFromSurface(renderer, sC4);
                SDL_Rect rC4 = { 10, WINDOW_HEIGHT - 20, sC4->w, sC4->h }; 
                SDL_RenderCopy(renderer, tC4, NULL, &rC4);
                SDL_FreeSurface(sC4); SDL_DestroyTexture(tC4);
            }
            SDL_SetRenderDrawColor(renderer, 0, 150, 0, 255); SDL_RenderFillRect(renderer, &startButton);
            SDL_SetRenderDrawColor(renderer, 150, 0, 0, 255); SDL_RenderFillRect(renderer, &quitButton);
            if (font) {
                SDL_Surface* sS = TTF_RenderText_Solid(font, "START", white);
                SDL_Texture* tS = SDL_CreateTextureFromSurface(renderer, sS);
                SDL_Rect rS = { startButton.x + (startButton.w/2 - sS->w/2), startButton.y + 10, sS->w, sS->h }; SDL_RenderCopy(renderer, tS, NULL, &rS);
                SDL_FreeSurface(sS); SDL_DestroyTexture(tS);
                SDL_Surface* sQ = TTF_RenderText_Solid(font, "QUIT", white);
                SDL_Texture* tQ = SDL_CreateTextureFromSurface(renderer, sQ);
                SDL_Rect rQ = { quitButton.x + (quitButton.w/2 - sQ->w/2), quitButton.y + 10, sQ->w, sQ->h }; SDL_RenderCopy(renderer, tQ, NULL, &rQ);
                SDL_FreeSurface(sQ); SDL_DestroyTexture(tQ);
            }
        } else {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_Rect gameArea = { 20, 20, GAME_WIDTH, GAME_HEIGHT }; SDL_RenderFillRect(renderer, &gameArea);
            for (int x = 0; x < COLS; x++) for (int y = 0; y < ROWS; y++) if (sand_map[x][y] != 0) {
                Uint32 c = sand_map[x][y]; SDL_SetRenderDrawColor(renderer, (c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF, 255);
                SDL_Rect grain = { 20 + (x * SAND_SIZE), 20 + (y * SAND_SIZE), SAND_SIZE, SAND_SIZE }; SDL_RenderFillRect(renderer, &grain);
            }
            SDL_SetRenderDrawColor(renderer, (currentPiece.color >> 16) & 0xFF, (currentPiece.color >> 8) & 0xFF, currentPiece.color & 0xFF, 255);
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (SHAPES[currentPiece.type][i][j]) {
                SDL_Rect r = { 20 + ((currentPiece.x + (j * BLOCK_SCALE)) * SAND_SIZE), 20 + ((currentPiece.y + (i * BLOCK_SCALE)) * SAND_SIZE), SAND_SIZE * BLOCK_SCALE, SAND_SIZE * BLOCK_SCALE };
                SDL_RenderFillRect(renderer, &r);
            }
            SDL_SetRenderDrawColor(renderer, 25, 25, 25, 255);
            SDL_Rect nBox = { 430, 90, 140, 140 }; SDL_RenderFillRect(renderer, &nBox);
            // next piece display with color
            SDL_SetRenderDrawColor(renderer, (nextColor >> 16) & 0xFF, (nextColor >> 8) & 0xFF, nextColor & 0xFF, 255);
            for (int i = 0; i < 4; i++) for (int j = 0; j < 4; j++) if (SHAPES[nextType][i][j]) {
                SDL_Rect nr = { 460 + (j * 20), 120 + (i * 20), 18, 18 }; SDL_RenderFillRect(renderer, &nr);
            }
            if (font) {
                SDL_Surface* sN = TTF_RenderText_Solid(font, "NEXT", white); SDL_Texture* tN = SDL_CreateTextureFromSurface(renderer, sN);
                SDL_Rect rN = { 430, 240, sN->w, sN->h }; SDL_RenderCopy(renderer, tN, NULL, &rN);
                SDL_FreeSurface(sN); SDL_DestroyTexture(tN);
                char sB[32]; sprintf(sB, "SCORE: %d", score);
                SDL_Surface* sSc = TTF_RenderText_Solid(font, sB, white); SDL_Texture* tSc = SDL_CreateTextureFromSurface(renderer, sSc);
                SDL_Rect rSc = { 430, 310, sSc->w, sSc->h }; SDL_RenderCopy(renderer, tSc, NULL, &rSc);
                SDL_FreeSurface(sSc); SDL_DestroyTexture(tSc);
            }
        }
        SDL_RenderPresent(renderer); SDL_Delay(16);
    }
    if (titleFont) TTF_CloseFont(titleFont);
    if (creditFont) TTF_CloseFont(creditFont);
    TTF_Quit(); SDL_Quit(); return 0;
}