#ifndef SAND_H
#define SAND_H

#include <SDL2/SDL.h>

#define GAME_WIDTH 380
#define GAME_HEIGHT 660
#define SAND_SIZE 4
#define ROWS (GAME_HEIGHT / SAND_SIZE)
#define COLS (GAME_WIDTH / SAND_SIZE)

// falling piece wala
typedef struct {
    int x, y;
    int type; // square ko 0, line ko 1,etc.
    Uint32 color;
    bool active;
} FallingPiece;

#endif